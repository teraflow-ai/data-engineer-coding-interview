import os
import json
import boto3

sns = boto3.client('sns')

SNSTOPIC = os.environ['SnsTopic']
JOBNAME = os.environ['GlueJobName']

def sns_publish(sns_message:str):

    sns.publish(
        TopicArn= SNSTOPIC,
        Message=f'Good day\n The following failure occurred:\n{sns_message}',
        Subject=f'{JOBNAME} failure',
    )



def lambda_handler(event, context):
    sns_message = event['detail']['message']
    sns_publish(sns_message)

    return {"message":"Email sent"}